package org.project.DrugAssistantBot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DrugAssistantBotApplicationTests {

	@Test
	void contextLoads() {
	}

}
